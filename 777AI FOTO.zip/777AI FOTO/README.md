# 777AI PHOTO

Aplikasi web AI untuk menjernihkan foto burik menjadi HD dengan 40+ efek.

## Cara Pakai

1. Buka `index.html` di browser modern (Chrome, Firefox, Edge).  
2. Pilih foto yang ingin dijernihkan.  
3. Pilih efek yang diinginkan.  
4. Klik "✨ Terapkan Efek & HD ✨".  
5. Setelah selesai, klik "💾 Download Hasil".  

## Deploy ke Netlify

1. Login ke [Netlify](https://www.netlify.com/).  
2. Pilih "New site from Git" atau drag folder `777AI-PHOTO/` ke area deploy.  
3. Tunggu proses deploy selesai.  
4. Aplikasi siap diakses online.  

**Catatan**: Pastikan folder `assets/` tetap ada agar logo, favicon & manifest tampil.